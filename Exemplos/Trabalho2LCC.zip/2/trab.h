#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

typedef int bool ;
typedef int true;
typedef int false;

typedef union{
	int *arri;
	char** arrs;
}array;

typedef struct var{
	int  end;
	array arr;
	int size;
	int  tipo;
	char* nome;
}*obj;
typedef struct lvar{
	obj x;
	struct lvar* prox;
}*lista;

typedef struct estado{
	obj x;
	int estado;
}*Estado;

typedef struct hash{
	int tam;
	Estado arr;
	int usados;
}*HashTable;

int existeHash(char* nome, HashTable h);
void dobrarHash(HashTable h); 
HashTable iniciarHashTable();
void iniciarEstado(Estado e,int tam);
int inserirHash(char* nome,int end,int size, HashTable h);
int calcularHash(char *nome,HashTable h);

int inserirEstado(char* nome,int end,int size, Estado e, int tam);

obj iniciarObj(int tipo,char* nome,int end,int size);
lista iniciarLista(obj o);

void addObjs(obj o, int size, char* value);
void addObj(obj o, int size,int value);

obj procuraNome(char* nome, lista l);
int getValue(obj o, int size);


void imprimeObj(obj o);
void imprimeValor(obj o, int size);
void imprimeBool(obj o, int size);
void printEstado(Estado e,int tam);
void printHash(HashTable h);


bool somaBool(bool a,bool b);
bool subBool(bool a,bool b);

int somaInt(int a,int b);
int subInt(int a, int b);

char * somaString(char* a, char* b);
char * somaString(char*a, char* b);

bool compararS (char* a, char* b ,int cmp);
bool compararI (int a, int b ,int cmp);

void escreveFich(char* pal,int out);
char* toString(char s[], int x);


  int ciclo=0;
  int ciclos[10];
  int iciclo=0;
  int cond=0;
  int conds[10];
  int icond=0;

