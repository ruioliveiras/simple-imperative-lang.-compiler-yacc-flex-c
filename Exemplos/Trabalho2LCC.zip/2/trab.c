#include "trab.h"

obj iniciarObj(int tipo,char* nome,int end,int size){
	obj a =(obj)malloc(sizeof(struct var));
	if (tipo==0 || tipo==1){a->arr.arri =(int*) malloc(size*sizeof(int));}
	else if (tipo==2) {a->arr.arrs =(char**)malloc(size*sizeof(char));}
	a->size = size;
	a->end= end;
	a->nome = strdup(nome);
	a->tipo = tipo;
return a;
}

lista iniciarLista(obj o){
	lista a =(lista) malloc(sizeof(struct lvar));
	a->prox = NULL;
	a->x= o;
return a;
}

void addObjs(obj o,int size,char * value){
	o->arr.arrs[size-1]=strdup(value);
}
void addObj(obj o, int size, int value){
	o->arr.arri[size-1]= value;
}

int existeNome(char* nome, lista l){
	obj o = NULL;
	lista aux=l;
	while(aux && strcmp(aux->x->nome,nome)!=0)aux=aux->prox;
	if (aux) return 1;
return 0;
}

obj procuraNome(char* nome, lista l){
	obj o = NULL;
	lista aux=l;
	while(aux && strcmp(aux->x->nome,nome)!=0)aux=aux->prox;
	if (aux) o= aux->x;
return o;
}
/*
int daEnd(char*nome, lista l){
	obj o = NULL;
	lista aux=l;
	while(aux && strcmp(aux->x->nome,nome)!=0)aux=aux->prox;
	if (aux) return aux->x->end;
return -1;
}*/

int getValue(obj o, int size){
	return o->arr.arri[size-1];
}

void imprimeObj(obj o){
	if(o){
	printf("tipo:%d \nnome:%s \nendereco:%d\ntamanho:%d\n",o->tipo,o->nome,o->end,o->size);
	}
}

void imprimeBool(obj o, int size){
	if(o->arr.arri[size-1]==1){printf("True" );}
	else if(o->arr.arri[size-1]==0){printf("False" );}
	else printf("erro\n");
}

void imprimeValor(obj o, int size){
if (o->tipo==0)imprimeBool(o,size);
else if (o->tipo==1){printf("%d",o->arr.arri[size-1]);}
else if (o->tipo==2){printf("%s",o->arr.arrs[size-1]);}
}


bool somaBool(bool a, bool b){return (a || b);}
bool subBool(bool a,bool b){return(a && b);}

int somaInt(int a,int b){return(a+b);}
int subInt(int a, int b){return(a-b);}

char* somaString(char* a, char* b){return strcat(a,b);}
char* subString(char* a, char* b){return strstr(a,b);}

bool compararS (char* a, char* b ,int cmp){
	int x=strcmp(a,b);
	switch(cmp){
		case 0:
			return x<=0;
		case 1:
			return x>=0;
		case 2:
			return x==0;
		case 3:
			return x!=0;
		case 4:
			return x<0;
		case 5:
			return x >0;
	break;
	}
	return 0;
}
bool compararI (int a, int b ,int cmp){
	switch(cmp){
		case 0:
			return a<=b;
		case 1:
			return a>=b;
		case 2:
			return a==b;
		case 3:
			return a!=b;
		case 4:
			return a<b;
		case 5:
			return a >b;
	break;
	}
	return 0;
}

void printHash(HashTable h){
	printf("HASH:\nTamanho: %d\nUsados: %d\n",h->tam,h->usados );
	printEstado(h->arr,h->tam);
}
void printEstado(Estado e,int tam){
	int i=0;
	while(i<tam){
		printf("estado: %d\n",e[i].estado);
		imprimeObj(e[i].x);
		i++;
	}
}
void escreveFich(char* pal,int out){
	write(out,pal,strlen(pal));
}

 HashTable iniciarHashTable(int tam){
	HashTable h = (HashTable) malloc (sizeof(struct hash));
	h->tam = tam;
	h->arr = (Estado) malloc( sizeof(struct estado)*tam);
	iniciarEstado(h->arr,h->tam);
	h->usados=0;
	return h;
}

void iniciarEstado(Estado e,int tam){
	
	int i=0;
	while(i<tam){
		e[i].estado=-1;
		i++;
	}
}

int existeHash(char* nome, HashTable h){
	int r= calcularHash(nome,h);
	while(r<h->tam){
		if (h->arr[r].estado==-1){break;}
		else {if(strcmp(h->arr[r].x->nome,nome)==0)return 1;}
		r=(r+1%h->tam);
	}
	return 0;
}

int inserirHash(char* nome,int end,int size, HashTable h){
	if (existeHash(nome,h)) return 1;
	int r= calcularHash(nome,h);
	int vistos=0;
	while(vistos<h->tam){
		if (h->arr[r].estado==-1){	
									h->arr[r].x=iniciarObj(1,nome,end,size);
									h->arr[r].estado=0;
									h->usados++;
									if(h->usados==h->tam)dobrarHash(h);
									break;
								}
		r=(r+1%h->tam);
		vistos++;
	}
	return 0;
}

int inserirEstado(char* nome,int end,int size, Estado e, int tam){
	int r= strlen(nome)%tam;

	while(r<tam){
		if (e[r].estado==-1){
								e[r].x=iniciarObj(1,nome,end,size);
									e[r].estado=0;
									break;
								}
		r=(r+1%tam);
	}
	return 0;
}

int calcularHash(char *nome,HashTable h){
	int r=strlen(nome);
	r= r%h->tam;
	return r;
}

 void dobrarHash(HashTable h){
 	int i=0;
 	HashTable g= iniciarHashTable(2*(h->tam));
 	g->usados=h->usados;
 	obj x;

 	while(i<h->tam){
 		x=h->arr[i].x;
 		inserirHash(x->nome,x->end,x->size,g);
 		i++;
 	}
 	free(h);
 	h=g;	
 	 	printf("www\n" );
 	printHash(h);
 }
obj getObj(char* nome,HashTable h){
	int r=calcularHash(nome,h);
	if(existeHash(nome,h)){
	while(r<h->tam){
		if (h->arr[r].estado==0 && strcmp(h->arr[r].x->nome,nome)==0){
			return h->arr[r].x;
		}
		r=(r+1%h->tam);
	}
	return NULL;
		}
	}
	

int daEnd(char* nome,HashTable h){
	obj x= getObj(nome,h);
	if (x) return x->end;
	else -1;
}